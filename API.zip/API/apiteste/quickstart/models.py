from django.db import models

# Create your models here.
class Empressa(models.Model):
    nome_empressa = models.CharField(max_length = 200)
    contato_empressa = models.CharField(max_length = 200)
    endereco_empressa = models.CharField(max_length = 200)
    avaliacao_empressa = models.IntegerField(default=0)
    
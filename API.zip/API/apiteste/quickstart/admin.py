from django.contrib import admin
from .models import Empressa
# Register your models here.

admin.site.register(Empressa)